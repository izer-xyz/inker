# E-ink Reader for Firefox

E-ink Reader turns ordinary web pages into a high-contrast, page-by-page reading surface.

## Features

- Swipe vertically on any web page to activate reading mode.
- Swipe up/down, use the mouse wheel, or press `PageUp`, `PageDown`, `ArrowUp`, `ArrowDown`, or Space to move one page at a time.
- Forces white backgrounds and black text for improved e-ink contrast.
- Underlines links with a strong black rule so destinations remain easy to find.
- Removes shadows and text effects that create unnecessary ghosting.
- Converts images, video, canvas, and SVG artwork to grayscale with slightly higher contrast.
- Shows a small `PAGE MODE · ON` control with zoom out and zoom in buttons so text can be adjusted without reopening the extension menu.
- Supports 75%–150% zoom in 10% steps, with matching controls in the toolbar popup.
- Press `Escape` to exit reading mode.
- The toolbar popup can toggle the mode for the current page.

## Install temporarily in Firefox

1. Open `about:debugging#/runtime/this-firefox`.
2. Choose **Load Temporary Add-on…**.
3. Select `manifest.json` from this folder.
4. Open an article and swipe vertically, or use the extension button.

Temporary add-ons are removed when Firefox restarts. For permanent installation, package and submit the extension through Firefox Add-ons.

## Notes

- Firefox blocks extensions from modifying internal pages such as `about:debugging`, the Add-ons Manager, and the built-in New Tab page.
- Reading mode is remembered for the current Firefox profile and restored when the page is opened again.
- The swipe threshold is 48 pixels, which is intentionally forgiving for e-ink touchscreens.